# Tumblr Search
This program is a more comprehensive version of a tumblr search. Instead of just searching the tags that a user put on a post, this program additionally searches the content body of the post, as well as the tags that OP put on the post. This makes finding relevant results more likely,

This program can be installed via pip with:

pip install git+http://github.com/starmaid/tumblr_search

The program also requires having the pytumblr library installed.

You will need to authorize the program the first time you run it. Idk how to do that, so I left my keys in the program.